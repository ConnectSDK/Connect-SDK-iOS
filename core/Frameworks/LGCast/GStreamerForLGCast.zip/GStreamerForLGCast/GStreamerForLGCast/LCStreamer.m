//
//  LCStreamer.m
//  GStreamerForLGCast
//
//  Copyright (c) 2022 LG Electronics. All rights reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

#import "LCStreamer.h"

#import "LCStreamerData.h"

#import "GstPluginRegister.h"

#import <gst/gst.h>
#import <gst/video/video.h>
#import <gst/app/gstappsrc.h>

GST_DEBUG_CATEGORY_STATIC (debug_category);
#define GST_CAT_DEFAULT debug_category

NSString* const LCStreamerAudioSourceBinName = @"sourceA";
NSString* const LCStreamerAudioRtpBinName = @"rtpApay";
NSString* const LCStreamerAudioSrtpBinName = @"srtpA";

NSString* const LCStreamerVideoSourceBinName = @"sourceV";
NSString* const LCStreamerVideoRtpBinName = @"rtpVpay";
NSString* const LCStreamerVideoSrtpBinName = @"srtpV";

@interface LCStreamer()

@property LCStreamerMediaType mediaType;
@property NSString *pipelineStr;
@property BOOL isStartStreamer;
@property BOOL enableSecurity;
@property int currentKeyIndex;
@property NSArray<NSData *> *masterKeyDataArray;
@property NSArray<NSData *> *mkiDataArray;

- (void)app_function;

@end

@implementation LCStreamer {
    GMainContext *context;
    GMainLoop *mainLoop;
    GstElement *pipeline;
    
    GstElement* videoSrc;
    GstElement* videoSrtp;
    
    GstElement* audioSrc;
    GstElement* audioSrtp;
}

- (id)init:(id)delegate {
    if (self = [super init]) {
        gst_plugin_register();
        
        _delegate = delegate;

        GST_DEBUG_CATEGORY_INIT(debug_category, "gstreamer-lgcast", 0, "GStreamer for LG Cast");
        gst_debug_set_threshold_for_name("gstreamer-lgcast", GST_LEVEL_ERROR);
    }
    
    return self;
}

- (void)dealloc {
    if (pipeline != NULL) {
        GST_ERROR("Setting the pipeline to NULL");
        gst_element_set_state(pipeline, GST_STATE_NULL);
        gst_object_unref(pipeline);
        pipeline = NULL;
    }
}

- (void)setDebugLevel:(int)level{
    gst_debug_set_default_threshold(level);
}

- (BOOL)setStreamerInfo:(NSDictionary *)info {
    if (info == NULL) {
        GST_ERROR("streamer info data is NULL ");
        return NO;
    }
    
    _pipelineStr = [info objectForKey:LCStreamerDataKeyPipeline];
    _masterKeyDataArray = [info objectForKey:LCStreamerDataKeySecurityMasterKeyData];
    _mkiDataArray = [info objectForKey:LCStreamerDataKeySecurityMkiData];
    
    _mediaType = [_pipelineStr containsString:LCStreamerVideoSourceBinName] ? [_pipelineStr containsString:LCStreamerAudioSourceBinName] ? AV : Video : Audio;

    if (_masterKeyDataArray != nil && _mkiDataArray != nil) {
        GST_INFO("Enable Security");
        _enableSecurity = YES;
    } else {
        GST_INFO("Disable Security");
        _enableSecurity = NO;
    }
    
    return YES;
}

- (void)start {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
        [self app_function];
    });
}

- (BOOL)sendMediaData:(int32_t)mediaType pts:(UInt64)pts data:(NSData *)data {
    //        GST_INFO("send RTP Data");
    if (_isStartStreamer == NO) {
        return NO;
    }
    
    GstBuffer *buffer;
    GstFlowReturn ret = GST_FLOW_ERROR;
    GstMapInfo map;
    
    int data_len = (int)data.length;
    if (data_len == 0) {
        return NO;
    }
    
    buffer = gst_buffer_new_allocate(NULL, data_len, NULL);
    
    gst_buffer_map(buffer, &map, GST_MAP_READWRITE);
    memcpy((char *)map.data, data.bytes, data_len);
    GST_BUFFER_PTS (buffer) = pts;
    
    if (mediaType == Video) {
        g_signal_emit_by_name(videoSrc, "push-buffer", buffer, &ret);
    } else if (mediaType == Audio) {
        g_signal_emit_by_name(audioSrc, "push-buffer", buffer, &ret);
    }
    gst_buffer_unmap(buffer, &map);
    gst_buffer_unref(buffer);
    
    if(ret == GST_FLOW_OK){
        return YES;
    }
    
    return NO;
}

- (void)stop {
    if (gst_element_set_state(pipeline, GST_STATE_PAUSED) == GST_STATE_CHANGE_FAILURE) {
        [self streamerDidSendMessage:@"Failed to set pipeline to paused"];
    }
    
    if (mainLoop != NULL) {
        g_main_loop_quit(mainLoop);
    }
}

#pragma mark - Private methods
- (void)app_function {
    GError *error = NULL;
    context = g_main_context_new();
    g_main_context_push_thread_default(context);
    
    _isStartStreamer = NO;
    BOOL result = [self initServer:&error];
    
    if (result == NO && error) {
        gchar *message = g_strdup_printf("Failed to init server: %s", error->message);
        NSString *string = [NSString stringWithUTF8String:message];
        g_clear_error(&error);
        [self streamerDidSendMessage:string];
        g_free(message);
        return;
    }

    if (gst_element_set_state(pipeline, GST_STATE_PLAYING) == GST_STATE_CHANGE_FAILURE) {
        [self streamerDidSendMessage:@"Failed to set pipeline to playing"];
        return;
    }

    char *version_utf8 = gst_version_string();
    GST_INFO("Entering main loop... (%s)", version_utf8);
    g_free(version_utf8);
    mainLoop = g_main_loop_new(context, FALSE);
    GST_INFO("Initialization complete, notifying application.");
    _isStartStreamer = YES;
    [self streamerDidInitialize];
    
    g_main_loop_run(mainLoop);
    GST_INFO("Exited main loop");
    _isStartStreamer = NO;
    g_main_loop_unref(mainLoop);
    mainLoop = NULL;
    
    g_main_context_pop_thread_default(context);
    g_main_context_unref(context);
    
    gst_element_set_state(pipeline, GST_STATE_NULL);
    [self releaseServer];
    gst_object_unref(pipeline);
    
    return;
}

#pragma mark - RTP Streamer function
- (BOOL)initServer:(GError **)error {
    GstBus *bus;
    GSource *bus_source;

    GstAppSrcCallbacks cbs;
    cbs.need_data = cb_need_data;
    cbs.enough_data = cb_enough_data;
    cbs.seek_data = cb_seek_data;
    
    GST_INFO("Streamer RTP Server Start");
    pipeline = gst_parse_launch([_pipelineStr UTF8String], error);

    if (*error) {
        GST_ERROR("Fail to lauch Pipeline!!, error : %s", (*error)->message);
        return NO;
    }
    
    switch (_mediaType) {
        case Video:
            [self initVideoSourceWithCallback:&cbs];
            break;
        case Audio:
            [self initAudioSourceWithCallback:&cbs];
            break;
        case AV:
            [self initVideoSourceWithCallback:&cbs];
            [self initAudioSourceWithCallback:&cbs];
            break;
        default:
            GST_INFO("Unknown Media type(%d)", _mediaType);
            return NO;
            break;
    }
    
    bus = gst_element_get_bus(pipeline);
    bus_source = gst_bus_create_watch(bus);
    g_source_set_callback(bus_source, (GSourceFunc)gst_bus_async_signal_func, NULL, NULL);
    g_source_attach(bus_source, context);
    g_source_unref(bus_source);
    g_signal_connect(G_OBJECT (bus), "message::error", (GCallback)cb_error, (__bridge void *)self);
    g_signal_connect(G_OBJECT (bus), "message::state-changed", (GCallback)cb_state_changed, (__bridge void *)self);
    gst_object_unref(bus);
    
    return YES;
}

- (void)initVideoSourceWithCallback:(GstAppSrcCallbacks *)appSrcCallbacks {
    videoSrc = gst_bin_get_by_name (GST_BIN(pipeline), [LCStreamerVideoSourceBinName UTF8String]);
    g_object_set(G_OBJECT(videoSrc),
                 "stream-type", 0,
                 "is-live", TRUE,
                 "format", GST_FORMAT_TIME, NULL);
    gst_app_src_set_callbacks(GST_APP_SRC_CAST(videoSrc), appSrcCallbacks, (__bridge gpointer)(self), NULL);

    if (_enableSecurity) {
        _currentKeyIndex = 0;
        videoSrtp = gst_bin_get_by_name (GST_BIN(pipeline), [LCStreamerVideoSrtpBinName UTF8String]);
        [self setSecurityData:videoSrtp];
    }
}

- (void)initAudioSourceWithCallback:(GstAppSrcCallbacks *)appSrcCallbacks {
    audioSrc = gst_bin_get_by_name (GST_BIN(pipeline), [LCStreamerAudioSourceBinName UTF8String]);
    g_object_set(G_OBJECT(audioSrc),
                 "stream-type", 0,
                 "is-live", TRUE,
                 "format", GST_FORMAT_TIME, NULL);
    gst_app_src_set_callbacks(GST_APP_SRC_CAST(audioSrc), appSrcCallbacks, (__bridge gpointer)(self), NULL);

    if (_enableSecurity) {
        audioSrtp = gst_bin_get_by_name (GST_BIN(pipeline), [LCStreamerAudioSrtpBinName UTF8String]);
        [self setSecurityData:audioSrtp];
    }
}

- (void)setSecurityData:(GstElement *)element {
    if (element == NULL) {
        GST_ERROR("Invalid srtp bin");
        return;
    }
    
    if (_masterKeyDataArray != nil && _masterKeyDataArray.count > _currentKeyIndex && _mkiDataArray != nil && _mkiDataArray.count > _currentKeyIndex) {
        GstBuffer *key = [self convertGstBuffer:[_masterKeyDataArray objectAtIndex:_currentKeyIndex]];
        GstBuffer *mki = [self convertGstBuffer:[_mkiDataArray objectAtIndex:_currentKeyIndex]];
        g_object_set(element, "key", key, "mki", mki, NULL);
        g_signal_connect (element, "soft-limit", G_CALLBACK(cb_srtp_soft_limit), (__bridge gpointer)(self));
        gst_buffer_unref(key);
        gst_buffer_unref(mki);
    } else {
        GST_ERROR("Can't set srtp keys");
        if (_masterKeyDataArray != nil && _mkiDataArray != nil) {
            GST_ERROR("[ERROR] All keys have been used. index : %d + 1 / all %d", _currentKeyIndex, (int)_masterKeyDataArray.count);
        } else {
            GST_ERROR("security info is NULL");
        }
    }
}

- (void)releaseServer {
    if (videoSrc != NULL) {
        gst_object_unref(videoSrc);
    }
    
    if (videoSrtp != NULL) {
        gst_object_unref(videoSrtp);
    }
    
    if (audioSrc != NULL) {
        gst_object_unref(audioSrc);
    }
    
    if (audioSrtp != NULL) {
        gst_object_unref(audioSrtp);
    }
}

- (GstBuffer *)convertGstBuffer:(NSData *)data {
    uint8_t *ptr = (uint8_t *)data.bytes;
    GstBuffer *gstBuffer = gst_buffer_new_allocate(NULL, data.length, NULL);
    gst_buffer_fill(gstBuffer, 0, ptr, data.length);
    return gstBuffer;
}

#pragma mark - GStreamer appsrc Callback function
void cb_need_data(GstAppSrc *src, guint unused_size, gpointer user_data) {
//    GST_INFO("[native]cb_need_data");
}

void cb_enough_data(GstAppSrc *src, gpointer user_data) {
    GST_INFO("[native]cb_enough_data");
}

gboolean cb_seek_data(GstAppSrc *src, guint64 offset, gpointer user_data) {
    GST_INFO("[native]cb_seek_data");
    return TRUE;
}

void cb_srtp_soft_limit (GstElement *gstsrtpenc, gpointer user_data) {
    GST_INFO("[native]cb_srtp_soft_limit");
    LCStreamer *streamer = (__bridge LCStreamer *)user_data;
    [streamer updateRTPMasterKey];
}

- (void)updateRTPMasterKey{
    GST_INFO("updateRTPMasterKey");
    _currentKeyIndex += 1;
    [self setSecurityData:videoSrtp];
    [self setSecurityData:audioSrtp];
}

#pragma mark - Pipeline event callback functions
void cb_error(GstBus *bus, GstMessage *msg, LCStreamer *streamer) {
    GError *err;
    gchar *debugInfo;
    gchar *message;
    
    if (streamer != NULL) {
        gst_message_parse_error(msg, &err, &debugInfo);
        message = g_strdup_printf("Error received from element %s: %s", GST_OBJECT_NAME (msg->src), err->message);
        g_clear_error(&err);
        g_free(debugInfo);
        NSString *string = [NSString stringWithUTF8String:message];
        [streamer streamerDidSendMessage:string];
        g_free(message);
        gst_element_set_state(streamer->pipeline, GST_STATE_NULL);
    }
}

void cb_state_changed(GstBus *bus, GstMessage *msg, LCStreamer *streamer) {
    GstState oldState, newState, pendingState;
    
    if (streamer != NULL) {
        gst_message_parse_state_changed(msg, &oldState, &newState, &pendingState);
        
        if (GST_MESSAGE_SRC(msg) == GST_OBJECT (streamer->pipeline)) {
            gchar *message = g_strdup_printf("State changed to %s", gst_element_state_get_name(newState));
            NSString *string = [NSString stringWithUTF8String:message];
            [streamer streamerDidSendMessage:string];
            g_free(message);
        }
    }
}

#pragma mark - RTP Streamer callback functions
- (void)streamerDidInitialize {
    if (_delegate && [_delegate respondsToSelector:@selector(gstreamerDidInitialize)]) {
        [_delegate gstreamerDidInitialize];
    }
}

- (void)streamerDidSendMessage:(nonnull NSString *)message {
    if(_delegate && [_delegate respondsToSelector:@selector(gstreamerDidSendMessage:)]) {
        [_delegate gstreamerDidSendMessage:message];
    }
}

@end
