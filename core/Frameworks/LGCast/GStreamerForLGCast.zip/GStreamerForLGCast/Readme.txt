The instructions for building GStreamerForLGCast Framework on iOS.

1. Set up iOS-based Gstreamer development environment.
   - Guide Url : https://gstreamer.freedesktop.org/documentation/installing/for-ios-development.html
   - GStreamer version : 1.8.4
   
2. Open the GStreamerForLGCast.xcodeproj

3. Build

4. Select Product>"Show Build Folder in Finder" from the Xcode menu.

5. Go to the "Build/Products" directory.

6. Select the appropriate folder for the device to be applied. (ex: Debug-iphones, Release-iphones, etc)
